import React from "react";

const ApplyLeave = () => {
  return <div>ApplyLeave</div>;
};

export default ApplyLeave;
