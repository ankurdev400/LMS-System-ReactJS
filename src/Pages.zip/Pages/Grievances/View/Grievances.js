import React from "react";

const Grievances = () => {
  return <div>Grievances</div>;
};

export default Grievances;
